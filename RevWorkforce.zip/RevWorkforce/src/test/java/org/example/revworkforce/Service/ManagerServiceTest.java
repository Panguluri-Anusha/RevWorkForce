package org.example.revworkforce.Service;


import org.example.revworkforce.model.EmployeeGoal;
import org.example.revworkforce.model.PerformanceReview;
import org.example.revworkforce.service.ManagerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class ManagerServiceTest {
    private ManagerService managerService;

    @BeforeEach
    void setUp() {
        managerService = new ManagerService();
    }

    @Test
    void testViewTeamGoals() {
        // Manager ID 2 (Assuming ID 2 is a manager in your DB)
        List<EmployeeGoal> goals = managerService.getTeamGoals(2);

        assertNotNull(goals, "Goal list should not be null");
        // If team members have goals, size should be > 0
        assertTrue(goals.size() >= 0);
    }

    @Test
    void testUpdatePerformanceReview() {
        PerformanceReview review = new PerformanceReview();
        review.setReviewId(1);
        review.setManagerRating(5);
        review.setManagerComment("Excellent performance this quarter");
        review.setStatus("COMPLETED");

        boolean result = managerService.updateReview(review);
        assertTrue(result, "Manager should be able to complete a pending review");
    }
}