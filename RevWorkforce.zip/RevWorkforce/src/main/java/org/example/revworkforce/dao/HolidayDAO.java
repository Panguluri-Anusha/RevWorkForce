package org.example.revworkforce.dao;

import org.example.revworkforce.config.DBConnection;
import org.example.revworkforce.model.Holiday;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class HolidayDAO {

    // Get all holidays
    public List<Holiday> getAllHolidays() {
        List<Holiday> list = new ArrayList<>();
        String sql = "SELECT * FROM holidays ORDER BY holiday_date";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Holiday h = new Holiday();
                h.setHolidayId(rs.getInt("holiday_id"));
                h.setHolidayName(rs.getString("holiday_name"));

                // ✅ Convert java.sql.Date -> LocalDate
                java.sql.Date sqlDate = rs.getDate("holiday_date");
                if (sqlDate != null) {
                    LocalDate localDate = sqlDate.toLocalDate();
                    h.setHolidayDate(localDate);
                }

                list.add(h);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Add holiday
    public boolean addHoliday(Holiday holiday) {
        String sql = "INSERT INTO holidays (holiday_name, holiday_date) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, holiday.getHolidayName());

            // ✅ Convert LocalDate -> java.sql.Date
            ps.setDate(2, java.sql.Date.valueOf(holiday.getHolidayDate()));

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Remove holiday
    public boolean removeHoliday(int holidayId) {
        String sql = "DELETE FROM holidays WHERE holiday_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, holidayId);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public void truncateHolidayTable() {
        String sql = "TRUNCATE TABLE holiday";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public boolean deleteHolidayById(int id) {
        String sql = "DELETE FROM holiday WHERE holiday_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    }