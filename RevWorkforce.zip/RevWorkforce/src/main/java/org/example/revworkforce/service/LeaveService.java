package org.example.revworkforce.service;

/*
import org.example.revworkforce.dao.LeaveDAO;
import org.example.revworkforce.model.LeaveApplication;

import java.util.List;

public class LeaveService {

    private LeaveDAO leaveDAO = new LeaveDAO();

    // Apply leave
    public boolean applyLeave(LeaveApplication leave) {
        return leaveDAO.applyLeave(leave);
    }

    // Get leaves of an employee
    public List<LeaveApplication> getEmployeeLeaves(int employee_id) {
        return leaveDAO.getLeavesByEmployee(employee_id);
    }

    // Get pending leaves of a manager's team
    public List<LeaveApplication> getTeamPendingLeaves(int manager_id) {
        return leaveDAO.getPendingLeavesByManager(manager_id);
    }

    // Approve or reject leave
    public boolean decideLeave(int leave_id, int approved_by, String status, String manager_comment) {
        return leaveDAO.updateLeaveStatus(leave_id, approved_by, status, manager_comment);
    }
    public void showLeaveTypes() {

        String sql = "SELECT leave_type_id, leave_name, default_quota FROM leave_type";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("\n--- Available Leave Types ---");

            while (rs.next()) {

                System.out.println(
                        rs.getInt("leave_type_id") + ". " +
                                rs.getString("leave_name") +
                                " (Quota: " + rs.getInt("default_quota") + ")"
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
*/
//
//
//
//
//import org.example.revworkforce.dao.LeaveDAO;
//import org.example.revworkforce.model.LeaveApplication;
//import org.example.revworkforce.util.InputUtil;
//
//import java.text.SimpleDateFormat;
//
//import org.example.revworkforce.dao.LeaveDAO;
//import org.example.revworkforce.model.LeaveApplication;
//
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//

//
//import org.example.revworkforce.dao.LeaveDAO;
//import org.example.revworkforce.model.LeaveApplication;
//import org.example.revworkforce.model.LeaveStatus;
//
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//
//import static org.example.revworkforce.main.MainApp.leaveService;
//
//public class LeaveService {
//
//    private LeaveDAO leaveDAO = new LeaveDAO();
//
//    // Apply leave
//    public boolean applyLeave(LeaveApplication leave, String role) {
//        if ("ADMIN".equalsIgnoreCase(role)) {
//            leave.setStatus(LeaveStatus.APPROVED); // auto-approved
//            leave.setApprovedBy(leave.getEmployeeId());
//            return leaveDAO.applyLeave(leave);
//        } else {
//            leave.setStatus(LeaveStatus.PENDING); // pending approval
//            return leaveDAO.applyLeave(leave);
//        }
//    }
//
//    // Manager approves/rejects employee leave
//    public boolean managerDecideLeave(int leaveId, int managerId, boolean approve, String comment) {
//        String status = approve ? LeaveStatus.APPROVED_BY_MANAGER : LeaveStatus.REJECTED_BY_MANAGER;
//        return leaveDAO.updateLeaveStatus(leaveId, status, comment, managerId);
//    }
//
//    // Admin approves/rejects manager leave
//    public boolean adminDecideLeave(int leaveId, int adminId, boolean approve, String comment) {
//        String status = approve ? LeaveStatus.APPROVED : LeaveStatus.REJECTED;
//        return leaveDAO.updateLeaveStatus(leaveId, status, comment, adminId);
//    }
//
//    // Get pending leaves for manager
//    public List<LeaveApplication> getPendingLeavesForManager(int managerId) {
//        return leaveDAO.getPendingLeavesByManager(managerId);
//    }
//
//    // Get pending manager leaves for admin
//    public List<LeaveApplication> getPendingManagerLeaves() {
//        return leaveDAO.getLeavesByStatus(LeaveStatus.PENDING);
//    }
//
//    public List<String> getLeaveTypes() {
//        List<String> leaveTypes = new ArrayList<>();
//
//        try {
//            leaveTypes = leaveDAO.getAllLeaveTypes(); // DAO method returns List<String>
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        return leaveTypes;
//    }
//    public String formatDateOnly(Date date) {
//        if (date == null) return "";
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        return sdf.format(date);
//    }
//
//}

import org.example.revworkforce.dao.LeaveDAO;
import org.example.revworkforce.model.LeaveApplication;
//
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//
//public class LeaveService {
//
//    private LeaveDAO leaveDAO = new LeaveDAO();
//
//    // Role constant
//    public static final String ROLE_ADMIN = "ADMIN";
//
//    // ---------------- Apply Leave ----------------
//    public boolean applyLeave(LeaveApplication leave, String role) {
//        if (ROLE_ADMIN.equalsIgnoreCase(role)) {
//            leave.setStatus(LeaveStatus.APPROVED); // Admin auto-approved
//            leave.setApprovedBy(leave.getEmployeeId());
//            leave.setManagerComment("Auto-approved by Admin");
//        } else {
//            leave.setStatus(LeaveStatus.PENDING); // Pending manager approval
//        }
//        return leaveDAO.applyLeave(leave);
//    }
//
//    // ---------------- Decide Leave (Manager/Admin) ----------------
//    public boolean decideLeave(int leaveId, int approverId, String status, String comment) {
//        return leaveDAO.updateLeaveStatus(leaveId, status, comment, approverId);
//    }
//
//    // ---------------- Get Pending Leaves ----------------
//    public List<LeaveApplication> getTeamPendingLeaves(int managerId) {
//        // Fetch leaves for the manager's team
//        return leaveDAO.getPendingLeavesByManager(managerId);
//    }
//
//    // ---------------- Leave Types ----------------
//    public List<String> getLeaveTypes() {
//        List<String> leaveTypes = new ArrayList<>();
//        try {
//            leaveTypes = leaveDAO.getAllLeaveTypes();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return leaveTypes;
//    }
//
//    // ---------------- Employee Leaves ----------------
//    public List<LeaveApplication> getEmployeeLeaves(int employeeId) {
//        return leaveDAO.getLeavesByEmployee(employeeId);
//    }
//
//    // ---------------- Date Formatting ----------------
//    public Date formatDateOnly(Date date) {
//        if (date == null) return null;
//        try {
//            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//            return sdf.parse(sdf.format(date));
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//
//    public String formatDate(Date date) {
//        if (date == null) return "";
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        return sdf.format(date);
//    }
import org.example.revworkforce.dao.LeaveDAO;
import org.example.revworkforce.model.LeaveApplication;

import java.util.ArrayList;
//import org.example.revworkforce.model.LeaveStatus;
//
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//
//public class LeaveService {
//
//    private LeaveDAO leaveDAO = new LeaveDAO();
//    public static final String ROLE_ADMIN = "ADMIN";
//
//    // ---------------- Apply Leave ----------------
//    public boolean applyLeave(LeaveApplication leave, String role) {
//        if (ROLE_ADMIN.equalsIgnoreCase(role)) {
//            leave.setStatus(LeaveStatus.APPROVED);
//            leave.setApprovedBy(leave.getEmployeeId());
//            leave.setManagerComment("Auto-approved by Admin");
//        } else {
//            leave.setStatus(LeaveStatus.PENDING);
//        }
//        return leaveDAO.applyLeave(leave);
//    }
//
//    // ---------------- Decide Leave (Manager/Admin) ----------------
//    public boolean decideLeave(int leaveId, int approverId, String status, String comment) {
//        return leaveDAO.updateLeaveStatus(leaveId, status, comment, approverId);
//    }
//
//    // ---------------- Get Pending Leaves ----------------
//    public List<LeaveApplication> getTeamPendingLeaves(int employeeId, String role) {
//        if (ROLE_ADMIN.equalsIgnoreCase(role)) {
//            return leaveDAO.getLeavesByStatus(LeaveStatus.PENDING);
//        } else {
//            return leaveDAO.getPendingLeavesByManager(employeeId);
//        }
//    }
//
//    // ---------------- Get Leaves by Employee ----------------
//    public List<LeaveApplication> getEmployeeLeaves(int employeeId) {
//        return leaveDAO.getLeavesByEmployee(employeeId);
//    }
//
//    // ---------------- Get Leave Types ----------------
//    public List<String> getLeaveTypes() {
//        List<String> leaveTypes = new ArrayList<>();
//        try {
//            leaveTypes = leaveDAO.getAllLeaveTypes();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return leaveTypes;
//    }
//
//    // ---------------- Date Formatting ----------------
//    public Date formatDateOnly(Date date) {
//        if (date == null) return null;
//        try {
//            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//            return sdf.parse(sdf.format(date));
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//
//    public String formatDate(Date date) {
//        if (date == null) return "";
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        return sdf.format(date);
//    }
//}
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.example.revworkforce.model.LeaveStatus;
public class LeaveService {

    private LeaveDAO leaveDAO = new LeaveDAO();
    public static final String ROLE_ADMIN = "ADMIN";
    public static final String ROLE_MANAGER = "MANAGER";
    public static final String ROLE_EMPLOYEE = "EMPLOYEE";

    // 1. Apply Leave: Admin is auto-approved, others are pending
    public boolean applyLeave(LeaveApplication leave, String role) {
        if (ROLE_ADMIN.equalsIgnoreCase(role)) {
            // Rule: Admin leaves are self-approved
            leave.setStatus(LeaveStatus.APPROVED);
            leave.setApprovedBy(leave.getEmployeeId());
            leave.setManagerComment("System: Auto-approved for Admin");
        } else {
            // Rule: Employees and Managers stay PENDING for their respective bosses
            leave.setStatus(LeaveStatus.PENDING);
        }
        return leaveDAO.applyLeave(leave);
    }

    // 2. Get Pending Leaves (Hierarchy: Admin sees Managers, Manager sees Employees)
    public List<LeaveApplication> getPendingLeavesForUser(int currentUserId, String currentUserRole) {
        if (ROLE_ADMIN.equalsIgnoreCase(currentUserRole)) {
            // Admin sees all leaves submitted by users with ROLE_MANAGER
            return leaveDAO.getPendingLeavesForAdmin();
        } else if (ROLE_MANAGER.equalsIgnoreCase(currentUserRole)) {
            // Manager sees only PENDING leaves from their direct reports (ROLE_EMPLOYEE)
            return leaveDAO.getPendingLeavesByManager(currentUserId);
        }
        return new ArrayList<>();
    }

    // 3. Process Leave Decision
    public boolean decideLeave(int leaveId, int approverId, String status, String comment) {
        return leaveDAO.updateLeaveStatus(leaveId, status, comment, approverId);
    }

    // 4. Leave History
    public List<LeaveApplication> getEmployeeLeaveHistory(int employeeId) {
        return leaveDAO.getLeavesByEmployee(employeeId);
    }

    // 5. Utility: Date Formatting
    public String formatDate(Date date) {
        if (date == null) return "N/A";
        return new SimpleDateFormat("yyyy-MM-dd").format(date);
    }

    public List<String> getLeaveTypes() {
        List<String> leaveTypes = new ArrayList<>();
        try {
            // Fetch the list of leave type names from the DAO layer
            leaveTypes = leaveDAO.getAllLeaveTypes();
        } catch (Exception e) {
            // Log the error for debugging purposes in the console
            System.err.println("Error fetching leave types: " + e.getMessage());
        }
        return leaveTypes;
    }
    public Date formatDateOnly(Date date) {
        if (date == null) {
            return null;
        }
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String dateStr = sdf.format(date);
            return sdf.parse(dateStr);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<LeaveApplication> getEmployeeLeaves(int employeeId) {
        // Retrieve the list of leaves from the database via the DAO
        return leaveDAO.getLeavesByEmployee(employeeId);
    }

    public List<LeaveApplication> getTeamPendingLeaves(int employeeId, String role) {
        if (ROLE_ADMIN.equalsIgnoreCase(role)) {
            // Rule: Admin sees all leaves submitted by Managers
            return leaveDAO.getPendingLeavesForAdmin();
        } else if (ROLE_MANAGER.equalsIgnoreCase(role)) {
            // Rule: Manager sees only PENDING leaves from their direct reports
            return leaveDAO.getPendingLeavesByManager(employeeId);
        }
        // Regular employees do not have a team to manage
        return new ArrayList<>();
    }
}